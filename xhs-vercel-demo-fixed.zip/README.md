# 小红书收藏夹整理助手 Demo（Vercel 修复版）

部署建议：
1. 不要直接上传旧 zip。
2. 优先使用这个修复版 zip，或解压后把文件推到 GitHub 再导入 Vercel。
3. 这是纯静态站点，根目录直接包含 `index.html`、`package.json`、`vercel.json`。

如果 Vercel 询问配置：
- Framework Preset: Other
- Build Command: `npm run build`
- Output Directory: 留空
